import {tr} from './i18n/ui.mjs';
import {reviewConfirmed,programSelected} from './state.mjs';
import {zipStore} from '../shared/core/zip.mjs';
import {FORMS,FORM_NOUN,FORM_CODE,FORM_LANGUAGES,FORM_LANGUAGE_NAME,listsPeople,FIXED_ROWS,emptyAnswers,reviseAnswer,reviseGroup,confirmApplication,currentApplication,compatibleFacts,adoptFact,prefillApplication,applicationPeople,peopleCapacity,setApplicationPeople,documentUse,fieldLabel,recordLabel,filledSummary,remainingSummary,summaryText,pageList} from './form-adapter.mjs';
import {formPlan,releasedMap} from './form-renderer.mjs';
import {loadFormAssets,renderInWorker,previewPdf} from './form-browser.mjs';
let active=null,job=null,output=null,serial=0;
// A form is filled on the English edition, whatever the interface language. Another official edition is used only
// when the owner chooses it in the form dialog; the choice lasts for the session.
const chosenLanguage=new Map();
export const formLanguage=id=>chosenLanguage.get(id)??'en';
const fileStem=()=>active.language==='en'?active.id:`${active.id}-${active.language}`;
// The choice of edition, shown beside the form's button on the package screen and again in the form dialog. It is
// offered only for a form the state publishes in more than one language.
export function formLanguageChoice(id,esc){const languages=FORM_LANGUAGES[id]||[];if(languages.length<2)return '';
 return `<label class="field form-language-choice">${esc(tr('Official form language'))}<select data-form-language="${id}">${languages.map(l=>`<option value="${l}" ${l===formLanguage(id)?'selected':''}>${esc(FORM_LANGUAGE_NAME[l])}</option>`).join('')}</select></label><small class="form-language-note">${esc(tr('The state publishes this form in these languages. Your answers are written as you entered them and are not translated.'))}</small>`;
}
const joined=words=>words.length<2?words.join(''):words.slice(0,-1).join(', ')+' and '+words.at(-1);
// The filled content in the order of the form: section, PDF page, one line per record and where it came from.
// With `jump`, each page number is a button that scrolls the preview below to that page.
function filledHtml(summary,esc,jump=false){
 const page=n=>jump?`<button type="button" class="text-link" data-action="form-page" data-page="${n}">${esc(tr('PDF page {page}',{page:n}))}</button>`:esc(tr('PDF page {page}',{page:n}));
 return summary.sections.map(s=>`<h4>${esc(s.label)}<small>${s.pages.map(page).join(' ')}</small></h4><ul>${s.records.map(r=>`<li>${r.label?`<strong>${esc(r.label)}</strong>: `:''}${r.items.map(i=>`${esc(i.label.replace(/[?:]$/,''))}: <strong>${esc(i.value)}</strong>`).join('; ')}${r.from.length?`<small>${esc(tr('From {sources}',{sources:joined(r.from)}))}</small>`:''}</li>`).join('')}</ul>`).join('')+
  (summary.unplaced.length?`<h4>${esc(tr('Entered, but not on the PDF'))}</h4><ul>${summary.unplaced.map(u=>`<li>${esc(u.section)} · ${esc(u.label)}: <strong>${esc(u.value)}</strong><small>${esc(tr(u.why))}</small></li>`).join('')}</ul>`:'');
}
// What the owner still has to do, grouped so the list can be read at a glance.
function remainingHtml(left,esc){
 const some=fields=>fields.length>6?fields.slice(0,6).join(', ')+', '+tr('and {count} more',{count:fields.length-6}):fields.join(', ');
 return `<ul>${left.open.map(o=>`<li><strong>${esc(o.label)}</strong>: ${esc(tr(o.count===1?'{count} answer left':'{count} answers left',{count:o.count}))}<small>${esc(some(o.fields))}</small></li>`).join('')}${left.untouched.length?`<li><strong>${esc(tr('Sections not started ({count})',{count:left.untouched.length}))}</strong><small>${esc(left.untouched.join('; '))}</small></li>`:''}${left.manual.map(m=>`<li><strong>${esc(tr('PDF page {page}',{page:m.page}))}</strong>: ${esc(m.text)}<small>${esc(tr('Complete this by hand.'))}</small></li>`).join('')}</ul>`;
}
const formAssets=new Map();
export function clearFormPreview(){serial++;job?.abort();job=null;output=null;active=null;}
export const applicationFormButtons=(program,enabled=false,form=program==='CalFresh'?'cf285':'ccfrm604')=>`<button class="btn btn-primary" ${enabled?'':'disabled title="Confirm reviewed details in Review first"'} data-action="official-form" data-form="${form}">${tr({application:'Generate {program} package ({form})',recertification:'Generate {program} recertification ({form})','periodic report':'Generate {program} periodic report ({form})'}[FORM_NOUN[form]],{program,form:FORM_CODE[form]})}</button>`;
export function applicationAnswerSummary(state,id,esc){
 const d=state.formAnswers[id],assets=formAssets.get(id),answered=d?.answers.filter(a=>a.status==='answered')||[];
 if(!answered.length)return '<section class="application-answer-summary"><h3 data-i18n=ui156>Your application answers</h3><p data-i18n=ui157>No application answers entered yet. Prepare your answers below. Quick-check estimates are not copied into exact PDF fields.</p></section>';
 const current=currentApplication(d,state);
 if(assets){const summary=filledSummary(d,state,assets.inventory,assets.map);
  return `<section class="application-answer-summary filled-summary"><h3 data-i18n=ui156>Your application answers</h3><p>${current?'Confirmed for preparation':'Draft — review and confirm these answers'}. ${summary.boxes?esc(tr('{count} fields will be filled on {pages}.',{count:summary.boxes,pages:pageList(summary.pages)})):esc(tr('No answer reaches the PDF yet.'))}</p>${filledHtml(summary,esc)}</section>`;}
 return `<section class="application-answer-summary"><h3 data-i18n=ui156>Your application answers</h3><p>${current?'Confirmed for preparation':'Draft — review and confirm these answers'}. These are the values selected for your application draft.</p><dl class="cf-facts">${answered.map(a=>{
 const group=d.groups.find(g=>g.groupId===a.groupId),definition=assets?.inventory.groups.find(g=>g.id===a.groupId),label=fieldLabel(a.groupId,a.field,definition?.fields.find(f=>f.key===a.field)?.label||a.field.replaceAll('_',' ')),bindings=assets?.map.bindings.filter(b=>b.groupId===a.groupId&&b.row===a.row&&b.field===a.field&&(b.optionValue===undefined||b.optionValue===a.value))||[];
 const excluded=group?.status!=='applicable'||a.row>=group.rowCount;
 const pages=[...new Set(bindings.map(b=>b.page))];
 const destination=excluded?'Not included — section deferred, not applicable, or record removed':group.rowCount>definition?.printedCapacity?'Manual continuation required':pages.length?`PDF page${pages.length>1?'s':''} ${pages.join(', ')} · unsigned draft`:'Complete manually on the official form';
 return `<div><dt>${esc(label)}<small>${esc(definition?.label||a.groupId)} · ${esc(recordLabel(a.groupId,a.row))}</small></dt><dd>${esc(typeof a.value==='boolean'?(a.value?'Yes':'No'):a.value)}<small>${esc(destination)}</small></dd></div>`;
 }).join('')}</dl></section>`;
}
export function connectForms({getState,modal,esc,btn,download,close,refresh=()=>{}}){
 const state=()=>getState(),data=()=>state().formAnswers[active.id];
 const key=a=>`${a.groupId}|${a.row}|${a.field}`;
 const PERSON_ORIGIN={you:'You, from your household details',household:'Household member you listed',document:'Named on your documents'};
 // The owner chooses who is on the application; each choice fills one person record, which stays editable.
 function peoplePanel(){const {map,id}=active;if(!listsPeople(id))return '';const people=applicationPeople(state()),chosen=data().people||[],room=peopleCapacity(id,map);
  if(!people.length)return `<section class="card pad"><h3>${esc(tr('People in this application'))}</h3><p>${esc(tr('Enter your household details, or add documents that name the people, to choose them here. You can also type each person in the sections below.'))}</p></section>`;
  return `<section class="card pad"><h3>${esc(tr('People in this application'))}</h3><p>${esc(tr(id==='ccfrm604'?'Choose who this application is for. Each person fills one person record below, with the name split into first, middle and last. A birth date is added where one of your documents lists it. Check every name part and date.':'Choose who this application is for. Each person fills one record of the household roster below. A birth date and relationship are added where one of your documents lists them; otherwise add them yourself.'))}</p>${people.map(p=>`<label class="check-row"><input type="checkbox" data-form-person="${esc(p.name)}"${chosen.includes(p.name)?' checked':''}${!chosen.includes(p.name)&&chosen.length>=room?' disabled':''}><span>${esc(p.name)}<small>${esc(tr(PERSON_ORIGIN[p.origin]))}</small></span></label>`).join('')}${chosen.length>=room?`<p class="small">${esc(tr('This form has room for {count} people. Add anyone else on the official form.',{count:room}))}</p>`:''}</section>`;
 }
 // Shows what each document gave this application, so an empty section can be traced to its cause.
 function documentsPanel(){const rows=documentUse(data(),state()),name=id=>active.inventory.groups.find(g=>g.id===id)?.label||id;
  if(!rows.length)return '';
  return `<section class="card pad"><h3>${esc(tr('What your documents filled'))}</h3><ul>${rows.map(r=>`<li><strong>${esc(r.file)}</strong>: ${esc(r.groups.length?r.groups.map(name).join('; '):tr('Not used.')+' '+tr(r.note))}</li>`).join('')}</ul></section>`;
 }
 function editor(){const expanded=[...document.querySelectorAll('.form-group[open]')].map(el=>el.dataset.groupView);const {inventory,map,id}=active,d=data();
  modal(`${FORMS[id]} ${FORM_NOUN[id]} details`,`<p>Prepare an unsigned copy of ${esc(inventory.title)}. Answer the sections that apply, or leave them for the original form. Available reviewed details are filled in below. Check them and add only what is missing. Income ranges are not treated as exact amounts.</p><p>Generate an unsigned draft using the original official form. Check the filled pages and complete missing items before signing or submitting.</p>${d.demoFixture?'<p><strong>Fictional demo — do not submit.</strong> These additional answers come from the demo questionnaire. They are not AI-extracted facts.</p>':peoplePanel()+documentsPanel()}<div id="form-editor">${inventory.groups.filter(g=>!g.manualOnly&&map.bindings.some(b=>b.groupId===g.id)).map(g=>{
   const group=d.groups.find(x=>x.groupId===g.id),status=group?.status||'deferred',rows=FIXED_ROWS[g.id]?.length||group?.rowCount||1;
   return `<details class="form-group" data-group-view="${g.id}"${expanded.includes(g.id)||(!expanded.length&&g===inventory.groups.find(x=>!x.manualOnly&&map.bindings.some(b=>b.groupId===x.id)))?' open':''}><summary>${esc(g.label)}</summary>${g.hint?`<p class="small">${esc(tr(g.hint))}</p>`:''}<label>Prepare this section<select data-form-group="${g.id}">${[['deferred','Answer on the official form'],['applicable','Yes — prepare answers here'],['not_applicable','Not applicable']].map(([v,t])=>`<option value="${v}"${status===v?' selected':''}>${t}</option>`).join('')}</select></label>${status!=='not_applicable'?`${status==='deferred'?'<p>Enter an answer to include this section. Leave it blank to finish on the official form.</p>':''}${g.printedCapacity>1&&!FIXED_ROWS[g.id]?`<label>Number of people or records<input type="number" min="1" max="100" value="${rows}" data-form-rows="${g.id}"></label>`:''}${rows>g.printedCapacity?`<p>Only ${g.printedCapacity} records fit here. This section will need manual continuation; no records will be silently dropped.</p>`:''}${Array.from({length:Math.min(rows,g.printedCapacity)},(_,row)=>`<fieldset><legend>${esc(recordLabel(g.id,row))}</legend>${g.fields.filter(f=>map.bindings.some(b=>b.groupId===g.id&&b.row===row&&b.field===f.key)).map(f=>{
    const k=key({groupId:g.id,row,field:f.key}),a=d.answers.find(x=>key(x)===k),bs=map.bindings.filter(b=>b.groupId===g.id&&b.row===row&&b.field===f.key),choices=[...new Set(bs.filter(b=>b.optionValue!==undefined).map(b=>b.optionValue))],sources=compatibleFacts(state(),f.key);
    const control=choices.length?`<select data-form-answer="${k}" data-answer-type="${f.type}"><option value="">Leave unanswered</option>${choices.map(v=>`<option value="${esc(String(v))}"${a?.status==='answered'&&a.value===v?' selected':''}>${typeof v==='boolean'?v?'Yes':'No':esc(v)}</option>`).join('')}</select>`:`<input data-form-answer="${k}" value="${esc(a?.status==='answered'?a.value:'')}" maxlength="4000">`;
    return `<label class="field">${esc(fieldLabel(g.id,f.key,f.label))}${control}</label>${a?.chosenPerson&&a.status==='answered'?'<small>From the person you chose. Check it; you can edit this value.</small>':a?.autoPrefilled&&a.status==='answered'?'<small>Filled from your reviewed details. You can edit this value.</small>':''}${sources.length?`<label>Use a confirmed source for this answer<select data-form-source="${k}"><option value="" disabled${a?.sourceRefs?.length===1&&sources.some(f=>f.id===a.sourceRefs[0].id)?'':' selected'}>Choose a source (optional)</option>${sources.map(f=>{const doc=state().docs.find(d=>d.id===f.documentId),chosen=a?.sourceRefs?.length===1&&a.sourceRefs[0].id===f.id;return `<option value="${esc(f.id)}"${chosen?' selected':''}>${esc([f.value,doc?.filename||'Entered detail',f.page?'Page '+f.page:'',f.period].filter(Boolean).join(' · '))}</option>`;}).join('')}</select></label>`:''}`;}).join('')}</fieldset>`).join('')}`:''}</details>`;}).join('')}</div><p>Signatures, consent/elections, sensitive identity details, and other unsupported questions must be completed directly on the original form. Confirmation here is not a signature.</p><a href="${inventory.officialUrl}" target="_blank" rel="noopener noreferrer" data-i18n=ui165>Open official blank application</a>`,btn('form-confirm','Confirm these application answers',true)+btn('close','Done'));
 }
 function planView(){const d=data(),{inventory,map}=active,plan=formPlan(inventory,map,d);active.plan=plan;
  const left=remainingSummary(plan.missing,plan.manualActions,inventory,map);
  modal(`${FORMS[active.id]} ${FORM_NOUN[active.id]} answers`,`${applicationAnswerSummary(state(),active.id,esc)}<p>${plan.operations.length?`${plan.operations.length} PDF field placements planned.`:'No PDF field placements planned yet. Enter application answers to prepare them.'} ${esc(tr('{answers} answers are still open in {sections} sections, and {untouched} sections are not started.',{answers:left.answers,sections:left.open.length,untouched:left.untouched.length}))} Nothing is signed or submitted.</p>${!releasedMap(map)?'<p role="status">The field mapping has not completed independent review. Your download will be marked as an unsigned draft. Review every filled value and finish any missing items on the official form.</p>':''}${formLanguageChoice(active.id,esc)}<details class="filled-summary"><summary>Items to finish on the form</summary>${remainingHtml(left,esc)}</details><a href="${map.officialUrl??inventory.officialUrl}" target="_blank" rel="noopener noreferrer" data-i18n=ui164>Open official application</a>`,btn('form-preview','Generate filled application draft',true)+btn('form-blank','Preview blank official form')+btn('form-edit','Edit application answers')+btn('close','Done'));
 }
 // Both summaries of a finished draft: only boxes the writer reports as written count as filled.
 function summaries(report,snapshot){const {inventory,map}=active;
  return {filled:filledSummary(snapshot,state(),inventory,map,new Set(report.written.map(w=>w.groupId+'|'+w.row+'|'+w.field))),left:remainingSummary(report.missing,report.manualActions,inventory,map)};
 }
 async function action(a,b){
  if((a==='official-form'||a.startsWith('form-'))&&!reviewConfirmed(state()))throw Error('Confirm reviewed details in Review before generating a package.');
  if((a==='official-form'||a.startsWith('form-'))&&!programSelected(state(),FORMS[a==='official-form'?b.dataset.form:active?.id]))throw Error('Choose this program in Quick check before generating its package.');
  if(a==='official-form'){clearFormPreview();const id=b.dataset.form;const token=serial;const language=formLanguage(id),assets=await loadFormAssets(id,language);if(token!==serial)return true;active={id,language,...assets};formAssets.set(id,assets);state().formAnswers[id]??=emptyAnswers(id);prefillApplication(data(),state(),assets.map);if(data().people?.length)setApplicationPeople(data(),state(),assets.map,data().people);refresh();if(currentApplication(data(),state()))planView();else editor();return true;}
  if(!a.startsWith('form-'))return false;if(!active)throw Error('Reopen application details.');
  if(a==='form-page'){document.querySelectorAll('#official-preview canvas')[Number(b.dataset.page)-1]?.scrollIntoView({behavior:'smooth',block:'start'});return true;}
  if(a==='form-edit'){job?.abort();output=null;editor();return true;}
  if(a==='form-review'){job?.abort();output=null;planView();return true;}
  if(a==='form-blank'){
   const token=++serial;job?.abort();job=new AbortController();const signal=job.signal;
   modal('Blank official application',`<p>This is the original blank form. Your entered answers have not been added.</p><p id="blank-preview-status" role="status">Loading pages…</p><div id="official-preview"></div>`,btn('form-review','Back to my answers',true)+btn('close','Done'));
   try{await previewPdf(active.template,document.querySelector('#official-preview'),signal);if(!signal.aborted&&token===serial)document.querySelector('#blank-preview-status').textContent='All pages loaded. This form is blank.';}catch(e){if(signal.aborted||token!==serial)return true;document.querySelector('#blank-preview-status').textContent='Preview could not load. Your answers are still available. Go back to open the official form or try again.';}return true;
  }
  if(a==='form-confirm'){for(const el of document.querySelectorAll('[data-form-answer]')){const [groupId,row,field]=el.dataset.formAnswer.split('|');const old=data().answers.find(a=>a.groupId===groupId&&a.row===Number(row)&&a.field===field);const displayed=old?.status==='answered'?String(old.value):'';if(el.value!==displayed)input({target:el});}state().formAnswers[active.id]=confirmApplication(data(),state());refresh();planView();return true;}
  if(a==='form-preview'){
   if(!currentApplication(data(),state()))throw Error('Answers changed. Review and confirm the current answers first.');
   if(!formPlan(active.inventory,active.map,data()).operations.length)throw Error('No answers are ready to fill. Choose Edit application answers, choose the people in this application or enter the details you know, then confirm them. You can also preview the blank form.');
   const snapshot=structuredClone(data()),token=++serial;job?.abort();job=new AbortController();const signal=job.signal;
   modal('Preparing your application','<p>Filling the original form on your device…</p>',btn('close','Cancel'));
   try{
   const result=await renderInWorker({...active,answers:snapshot,mode:releasedMap(active.map)?'released':'draft'},signal);
   if(signal.aborted||token!==serial)return true;
   if(!currentApplication(snapshot,state())||data().revision!==snapshot.revision)throw Error('Answers changed. Generate a new preview.');
   const {filled,left}=summaries(result.report,snapshot);output={...result,snapshot,filled,left};
   modal('Review your unsigned application',`<p>${result.report.status==='partial_unsigned_draft'?'Partially filled application — items still need attention.':'Filled application ready for your review and signature.'}</p>${result.report.fictionalDemo?'<p><strong>Fictional demo — do not submit.</strong></p>':''}<section class="filled-summary"><h3>${esc(tr('What was filled'))}</h3><p>${active.language==='en'?'':esc(tr('Filled on the official {language} form.',{language:FORM_LANGUAGE_NAME[active.language]}))+' '}${esc(tr('{count} fields filled on {pages}.',{count:result.report.written.length,pages:pageList(filled.pages)}))} ${esc(tr('Select a page number to see it below. Check each value against your documents.'))}</p>${filledHtml(filled,esc,true)}<h3>${esc(tr('What is left for you'))}</h3><p>${esc(tr('{answers} answers are still open in {sections} sections, and {untouched} sections are not started.',{answers:left.answers,sections:left.open.length,untouched:left.untouched.length}))} Inspect each page and finish all required signatures and consent choices yourself.</p><details><summary>${esc(tr('Show what is left'))}</summary>${remainingHtml(left,esc)}</details></section>${result.report.mode==='draft'?'<p>Unsigned draft — independent mapping review is incomplete. Nothing has been submitted.</p>':''}<div id="official-preview"></div>`,btn('form-save','Download filled PDF',true,'disabled')+btn('form-package','Download application package',false,'disabled')+btn('form-review','Back to answers')+btn('close','Done'));
   await previewPdf(result.bytes,document.querySelector('#official-preview'),signal);if(!signal.aborted&&token===serial&&currentApplication(snapshot,state())){document.querySelector('[data-action=form-save]').disabled=false;document.querySelector('[data-action=form-package]').disabled=false;}return true;
   }catch(error){if(signal.aborted||token!==serial)return true;output=null;planView();document.querySelector('#dialog-error').textContent=error.message||'Application could not be generated. Your answers are still available. Try again.';return true;}
  }
  if(a==='form-save'||a==='form-package'){if(!output||!currentApplication(output.snapshot,state())||data().revision!==output.snapshot.revision)throw Error('This preview is stale. Generate it again.');if(a==='form-save')download(output.bytes,`${fileStem()}-unsigned.pdf`,'application/pdf');else{
    const checklist=[output.report.fictionalDemo?'FICTIONAL DEMO — DO NOT SUBMIT':'UNSIGNED APPLICATION DRAFT — REVIEW BEFORE USE',FORMS[active.id]+' · '+active.inventory.title,'Nothing has been signed or submitted.',output.report.independentlyValidated?'':'Independent mapping review is incomplete. Check every populated field.',...output.report.missing.map(m=>`${m.groupId}${m.field?' / '+m.field:''}: ${m.reason.replaceAll('_',' ')}${m.value!==undefined?' — Your value: '+m.value:''}`),...output.report.manualActions.map(m=>`Page ${m.page}: ${m.text}`)].filter(Boolean).join('\n');
    download(zipStore([{name:`${fileStem()}-unsigned.pdf`,data:output.bytes},{name:'what-was-filled.txt',data:summaryText(output.filled,output.left)},{name:'items-to-finish.txt',data:checklist},{name:'application-answers.json',data:JSON.stringify(output.snapshot,null,2)},{name:'generation-report.json',data:JSON.stringify(output.report,null,2)}]),`${fileStem()}-application-package.zip`,'application/zip');
   }return true;}
  return false;
 }
 function input(event){const el=event.target;if(!active)return;
  if(el.dataset.formAnswer){const [groupId,row,field]=el.dataset.formAnswer.split('|');const group=data().groups.find(g=>g.groupId===groupId);if(el.value!==''&&group?.status!=='applicable'){reviseGroup(data(),groupId,'applicable',group?.rowCount||1);const control=document.querySelector(`[data-form-group="${groupId}"]`);if(control)control.value='applicable';}reviseAnswer(data(),{groupId,row:Number(row),field,status:el.value===''?'unknown':'answered',value:el.dataset.answerType==='bool'?el.value==='true':el.value,sourceIds:['owner-entry']});output=null;job?.abort();refresh();}
 }
 function change(event){const el=event.target;
  if(el.dataset.formLanguage){const id=el.dataset.formLanguage,language=el.value,before=formLanguage(id);if(!FORM_LANGUAGES[id]?.includes(language))return;chosenLanguage.set(id,language);
   // Chosen on the package screen: the edition is loaded when the form is opened.
   if(!el.closest('#dialog')||active?.id!==id)return;
   const token=++serial;job?.abort();output=null;
   loadFormAssets(id,language).then(assets=>{if(token!==serial||active?.id!==id)return;active={id,language,...assets};formAssets.set(id,assets);refresh();planView();}).catch(()=>{chosenLanguage.set(id,before);const error=document.querySelector('#dialog-error');if(error)error.textContent='That edition of the form could not be loaded. Your answers are still available.';});return;}
  if(!active)return;
  if(el.dataset.formPerson){const chosen=(data().people||[]).filter(name=>name!==el.dataset.formPerson);if(el.checked)chosen.push(el.dataset.formPerson);setApplicationPeople(data(),state(),active.map,chosen);output=null;job?.abort();refresh();editor();return;}
  if(el.dataset.formGroup){const old=data().groups.find(g=>g.groupId===el.dataset.formGroup);reviseGroup(data(),el.dataset.formGroup,el.value,old?.rowCount||1);refresh();editor();}
  if(el.dataset.formRows){const count=Number(el.value);if(!Number.isInteger(count)||count<1||count>100){el.setCustomValidity('Enter 1–100 records.');el.reportValidity();return;}reviseGroup(data(),el.dataset.formRows,'applicable',count);refresh();editor();}
  if(el.dataset.formSource&&el.value){const [groupId,row,field]=el.dataset.formSource.split('|');adoptFact(data(),state(),{groupId,row:Number(row),field},el.value);const group=data().groups.find(g=>g.groupId===groupId);if(group?.status!=='applicable')reviseGroup(data(),groupId,'applicable',group?.rowCount||1);refresh();editor();}
 }
 return {action,input,change};
}
